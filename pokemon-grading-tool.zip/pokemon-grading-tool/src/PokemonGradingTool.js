import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

function PokemonGradingTool() {
    const [searchQuery, setSearchQuery] = useState("");
    const [language, setLanguage] = useState("English");
    const [cards, setCards] = useState([]);
    const [loading, setLoading] = useState(false);

    const handleSearch = async () => {
        if (!searchQuery) return; 
        setLoading(true);
        try {
            const params = new URLSearchParams({
                searchQuery: searchQuery,
                language: language,
            }).toString();

            console.log("Fetching with params:", params);
            const response = await fetch(
                `http://127.0.0.1:8000/api/cards/scrape_and_save/?${params}`
            );

            console.log("Response status:", response.status);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            console.log("API response:", data);
            setCards(Array.isArray(data.results) ? data.results : []);
        } catch (error) {
            console.error("Error fetching cards:", error);
            setCards([]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container py-5 text-white" style={{ backgroundColor: "#121212" }}>
            <h1 className="text-center mb-4">Pokemon Grading Tool</h1>
            <div className="mb-4 d-flex justify-content-center align-items-center">
                <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Enter card name..."
                    className="form-control me-2"
                    style={{ maxWidth: "300px" }}
                />
                <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    className="form-select me-2"
                    style={{ maxWidth: "150px" }}
                >
                    <option value="English">English</option>
                    <option value="Japanese">Japanese</option>
                </select>
                <button onClick={handleSearch} className="btn btn-primary">
                    Search
                </button>
            </div>
            {loading ? (
                <div className="text-center">
                    <div className="spinner-border text-light" role="status">
                        <span className="visually-hidden">Loading...</span>
                    </div>
                </div>
            ) : (
                <div className="row">
                    {cards?.length > 0 ? (
                        cards.map((card, index) => (
                            <div key={index} className="col-md-4 mb-4">
                                <div className="card bg-dark text-white">
                                    <div className="card-body">
                                        <h5 className="card-title">{card.card_name || "Unknown Card"}</h5>
                                        <p className="card-text">Set: {card.set_name || "N/A"}</p>
                                        <p className="card-text">TCGPlayer Price: ${card.tcgplayer_price || "N/A"}</p>
                                        <p className="card-text">PSA 10 Price: ${card.psa_10_price || "N/A"}</p>
                                        <p className="card-text">Price Delta: ${card.price_delta || "N/A"}</p>
                                        <p className="card-text">
                                            Profit Potential: {card.profit_potential || "N/A"}%
                                        </p>
                                    </div>
                                </div>
                            </div>
                        ))
                    ) : (
                        <p className="text-center">No cards found</p>
                    )}
                </div>
            )}
        </div>
    );
}


export default PokemonGradingTool;
