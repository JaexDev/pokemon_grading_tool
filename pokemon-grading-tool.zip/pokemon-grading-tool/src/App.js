import React from 'react';
import PokemonGradingTool from './PokemonGradingTool';

function App() {
    return (
        <div className="App">
            <PokemonGradingTool />
        </div>
    );
}

export default App;
